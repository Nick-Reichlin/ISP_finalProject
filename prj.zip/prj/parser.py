#!/usr/bin/env python

import pandas as pd
import pyodbc

data = pd.read_csv('C:/wamp64/www/isp/prj/uploads/data.csv')
df = pd.DataFrame(data)
# Connect to SQL Server
conn = pyodbc.connect('Driver={MySQL ODBC 8.0 ANSI Driver};'
                      'Server=localhost;'
                      'UID=root;'
                      'Port=3306;'
                      'Database=isp;'
                      'Trusted_Connection=yes;')
cursor = conn.cursor()

# Create Table
cursor.execute('''
 		CREATE TABLE data (
 			id int primary key,
 			name varchar(50),
 			price int
 			)
                ''')

# Insert DataFrame to Table
for index, row in df.iterrows():
    cursor.execute(" INSERT INTO data (id, name, price) values (?,?,?) ", row.id, row.name, row.price)
conn.commit()

print("Data was successfully sent to the server")