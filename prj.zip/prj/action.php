<html>
    <head>
        <title> Upload </title>
        <style>
        td, th, table {border: thin solid black;}
        </style>
    </head>
    <body>
        <?php
        $uploaddir = "C:/wamp64/www/isp/prj/uploads/";
        $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);

        echo '<pre>';
        if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
            echo "Success.\n";
        } else {
            echo "Failure.\n";
        }

        echo 'Here is some more debugging info:';
        print_r($_FILES);
        print "</pre>";
        $command = escapeshellcmd('C:/wamp64/www/isp/prj/parser.py');
        $output = shell_exec($command);
        echo $output;

        ?>
    </body>
</html>