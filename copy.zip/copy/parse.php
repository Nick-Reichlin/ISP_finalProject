<html>
    <head>
        <title> Upload </title>
        <style>
        td, th, table {border: thin solid black;}
        </style>
    </head>
    <body>
        <?php
        $command = escapeshellcmd('C:/wamp64/www/copy/parser.py');
        $output = shell_exec($command);
        echo $output;

        ?>
    </body>
</html>